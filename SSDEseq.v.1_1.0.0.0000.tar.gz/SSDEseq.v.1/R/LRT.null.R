#' A function for generating the null loglikelihood ratio test statistic distribution
#'
#' This function generats the null loglikelihood ratio test statistic distribution.
#' @param n number of observations in one group.
#' @param n0 number of observations in the other group.
#' @param num.Sim number of simulations.
#' @param verbal whether print computation details.
#' @keywords component distributions
#' @export
#' @examples
#' LRT.null()
LRT.null=function(n, n0, num.Sim, verbal)
{ if (missing(num.Sim)) {num.Sim=100000}

  BBLRT=rep(NA, num.Sim)
  for (s in 1:num.Sim)
  {x=rnorm(n, 20)
  x0=rnorm(n0, 20)
  oott= FUN.LRT(x, x0, verbal=verbal)
  BBLRT[s]=oott$`-2logLRT`
  }
  return(BBLRT)
}
