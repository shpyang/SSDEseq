#' A function for removing one outlier
#'
#' This function trucates one outlier to the next value in rank, if the outlier is 10 SD from the second in rank.
#' @param x data values.
#' @keywords remove one outlier
#' @export
#' @examples
#' FUN.RM()
FUN.RM=function(x)
{x=x[!is.na(x)]
ox=sort(x)
if (abs(ox[1]-ox[2])>10*sd(x)) {ox[1]=ox[2]}
ox=rev(sort(ox))
if (abs(ox[1]-ox[2])>10*sd(x)) {ox[1]=ox[2]}
x=ox
return (x)
}
