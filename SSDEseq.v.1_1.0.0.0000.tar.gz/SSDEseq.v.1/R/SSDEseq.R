
#' A function for identifying conponent distributions
#'
#' This function is the main fuction for identifying TWO conponent distributions.
#' @param Mx data matrix for the more heterogeneous group.
#' @param Mx0 data Matrix for the more homogeneous group.
#' @param boxcox whether performs box-cox transformation.
#' @param tit the main title if plot is created.
#' @param include.normal whether include another group as the reference.
#' @param iteration the maximum number of iteration used in the EM algorithm.
#' @param eps the criterium used in the EM algorithm.
#' @param verbal whether print computation details.
#' @param plotTF whether create a plot.
#' @param useKS whether use KS test change as the convergence criterium.
#' @keywords component distributions
#' @export
#' @examples
#' SSDEseq()
SSDEseq=function(Mx, Mx0, boxcox, m.tit, include.normal, iteration, eps, plotTF, verbal, useKS)
{ if (missing(useKS)) {useKS=FALSE}
  if (missing(m.tit)) {m.tit=""}
  if (missing(plotTF)) {plotTF=FALSE}
  if (missing(verbal)) {verbal=TRUE}
  if (missing(boxcox)) {boxcox=TRUE}
  if (missing(include.normal)) {include.normal=TRUE}
  if (missing(iteration)) {iteration=1000}
  if (missing(eps)) {eps=.0000000001}

  n=dim(Mx)[[2]]
  n0=dim(Mx0)[[2]]

  ngene=nrow(Mx)
  if (table(row.names(Mx)==row.names(Mx0))!=ngene) {print("The two groups have to match!"); break}

  gene.loglik <<- data.frame("gene"=row.names(Mx),"-2logLRT"=rep(NA, ngene), "mean expression"=rep(NA, ngene), "minor proportion"=rep(NA, ngene), "cutoff"=rep(NA, ngene), "t.test"=rep(NA, ngene), "t.p"=rep(NA, ngene), "df"=rep(NA, ngene), "chisq.p"=rep(NA, ngene), "sd.sd.ratio"=rep(NA, ngene), "KS.p"=rep(NA, ngene))
  Mx=as.matrix(Mx)
  Mx0=as.matrix(Mx0)

  for (ng in 1:ngene)
  {if (ng/100==round(ng/100)) {print (paste("Just completed the ", ng, "th gene", sep=""))}
    x0=Mx0[ng,]
    x=Mx[ng,]
    m.tit=row.names(Mx)[ng]

    if (sum(x0==min(x0))<n0*0.05 & sum(x)>n)
    {oott= FUN.LRT(x, x0, tit=m.tit, boxcox=boxcox, include.normal=include.normal, iteration=iteration, eps=eps, plotTF=plotTF, verbal=verbal, useKS=useKS)

    gene.loglik[ng,2] <<- oott$`-2logLRT`
    gene.loglik[ng,3] <<- mean(x)
    gene.loglik[ng,4] <<- min(oott[[1]])
    gene.loglik[ng,5] <<- oott[[7]]
    nn1=round(n*oott[[1]][1])
    nn2=round(n*oott[[1]][2])
    den=oott[[3]][1]^2/nn1+oott[[3]][2]^2/nn2
    ts=abs(diff(oott[[2]]))/sqrt(den)
    vs=(den)^2/(oott[[3]][1]^4/nn1^2/(nn1-1)+oott[[3]][2]^4/nn2^2/(nn2-1))
    gene.loglik[ng,6] <<- ts
    gene.loglik[ng,7] <<- 2*(1-pt(ts, vs))
    gene.loglik[ng,8] <<- vs
    gene.loglik[ng,9] <<- oott$chisq.p
    gene.loglik[ng,10] <<- round(oott$sd.sd.ratio, 3)
    gene.loglik[ng,11] <<- oott$KS.p
    }
  }
  out = gene.loglik[(!is.na(gene.loglik$X.2logLRT))&(!is.na(gene.loglik$t.p)),]

  return(out)
}

