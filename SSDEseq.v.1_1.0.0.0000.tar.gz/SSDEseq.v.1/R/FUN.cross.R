#' A function for idenfity the location where two CDF cross
#'
#' This function idenfities the location where two CDF cross.
#' @param xx data values
#' @param n number of observations
#' @param mus means of the data where the two CDF are associated with.
#' @param sds standard deviations of the data where the two CDF are associated with.
#' @param sp the two proportions of the data where the two CDF are associated with.
#' @keywords cross
#' @export
#' @examples
#' FUN.cross()
FUN.cross=function(xx, n, mus, sds, sp)
{n.out=1000
sx=seq(min(xx), max(xx), length.out = n.out)
fa=function(ix) sp[1]*dnorm(ix, mus[1], sds[1])
fb=function(ix) sp[2]*dnorm(ix, mus[2], sds[2])
fita=fa(sx)
fitb=fb(sx)

fitts=abs(fita-fitb)
tpf=turnpoints(fitts)$tppos
cross=sx[tpf][which(fitts[tpf]==min(fitts[tpf]))]

if (length(tpf)>5)
{simx1=rnorm(10000, mus[1], sds[1])
simx2=rnorm(10000, mus[2], sds[2])
simx=sort(c(simx1, simx2))
c1=ecdf(simx1)
c2=ecdf(simx2)
d.cdf=abs(c1(simx)-c2(simx))
md.cdf=max(d.cdf)
KScross=simx[which(d.cdf==md.cdf)][1]
diff.2cross=abs(sx[tpf]-KScross)
cross=sx[tpf][which(diff.2cross==min(diff.2cross))]
cross=NA
}

KS.p=d.cdf=NA
if (!is.na(cross))
{cdf1=pnorm(cross, mus[1], sds[1])
cdf2=pnorm(cross, mus[2], sds[2])
d.cdf=abs(cdf1-cdf2)
KS.p=exp(-2*d.cdf^2*round(n*sp[1])*round(n*sp[2])/n)
KS.p[KS.p>1]=1
}
return(list(cross=cross, KS.p=KS.p, d.cdf=d.cdf))
}

