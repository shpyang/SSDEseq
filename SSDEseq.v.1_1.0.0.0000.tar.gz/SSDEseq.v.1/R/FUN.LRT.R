#' A function for identifying conponent distributions
#'
#' This function identifis TWO conponent distributions.
#' @param x data values for the more heterogeneous group.
#' @param x0 data values for the more homogeneous group.
#' @param boxcox whether performs box-cox transformation.
#' @param tit the main title if plot is created.
#' @param include.normal whether include another group as the reference.
#' @param iteration the maximum number of iteration used in the EM algorithm.
#' @param eps the criterium used in the EM algorithm.
#' @param verbal whether print computation details.
#' @param plotTF whether create a plot.
#' @param useKS whether use KS test change as the convergence criterium.
#' @keywords component distributions
#' @export
#' @examples
#' FUN.LRT()
FUN.LRT=function (x, x0, boxcox, tit, include.normal, iteration, eps, verbal, plotTF, useKS)
{K=2
x=FUN.RM(x)
x0=x0[!is.na(x0)]
n=length(x)

if (missing(useKS)) {useKS=FALSE}
if (missing(tit)) {tit=""}
if (missing(plotTF)) {plotTF=FALSE}
if (missing(verbal)) {verbal=TRUE}
if (missing(boxcox)) {boxcox=TRUE}
if (missing(include.normal)) {include.normal=TRUE}
if (sum(x==min(x))>min(3, n*.03))
{stx=sort(unique(round(x,3)))
range=stx[2]-stx[1]
x[x==min(x)]=x[x==min(x)]+runif(sum(x==min(x)), -range, range)
}

if (boxcox)
{bcx=FUN.boxcox(x,x0)
x=bcx[[1]]
x0=bcx[[2]]
}
xx=c(x,x0)

if (missing(iteration)) {iteration=1000}
mx0=mean(x0)
n0=length(x0)
se0=sd(x0)/sqrt(n0)


if (missing(eps)) {eps=.0000000001}

CCC=matrix(rep(NA, n*K), ncol=K)

denx=density(x)
dd=ts(denx$y)
tp=turnpoints(dd)$tppos

if (length(tp)>1)
{xy=data.frame(denx$x[tp], denx$y[tp])
xy=xy[rev(order(xy[,2])),]
mus=xy[1:2,1]
} else
{dis=tp-c(1,length(dd))
wdis=which(abs(dis)==min(abs(dis)))
tp2=c(tp, tp-round(dis/2)[3-wdis])
mus=denx$x[tp2]
}

sp=rep(.5, K)
sds=rep(sd(x), K)*c(.5,.5)
cross0=loglik0=0

for (B in 1:iteration)
{
  for (i in 1:2)
  {CCC[,i]=sp[i]*dnorm(x, mus[i], sds[i])}
  CCC=CCC/rowSums(CCC)
  
  for (i in 1:2)
  {sp[i]=mean(CCC[,i]) }
  
  sp=sp/sum(sp)
  
  for (i in 1:2)
  {if (min(sp)*n>3)
  {mus[i]=mean(      (CCC[,i])*x)/sp[i]
  sds[i]=sqrt(mean(      (CCC[,i])*(x-mus[i])^2)/sp[i])
  if (sds[i]==0) {break}
  if (abs(mus[i]-mx0)==min(abs(mus-mx0)))
  {if (include.normal)
  {mus[i]=(sds[i]^2*mean(x0)+sum( round(CCC[,])* (CCC[,i])*x)*se0^2)/(sds[i]^2+n*sp[i]*se0^2)}
  }
  }
  }
  
  if (min(sds)>0)
  {loglik=   sum(log(dnorm(x, mus[1], sds[1])*sp[1]
                     +dnorm(x, mus[2], sds[2])*sp[2]))
  KS.p=d.cdf=NA
  if (useKS)
  {crosss=FUN.cross1(xx, n, mus, sds, sp)
  cross=crosss[[1]]
  }
  }
  
  if (useKS) {if (abs(cross-cross0)< eps) {break};cross0=cross} else
  {if (abs(loglik-loglik0)< eps) {break};loglik0=loglik}
}

muxx=mean(x)
sdxx=sd(x)
loglik.null=sum( log(dnorm(x, muxx, sdxx)))
crosss=FUN.cross(xx, n, mus, sds, sp)
cross=crosss[[1]]
KS.p=crosss[[2]]
d.cdf=crosss[[3]]

if (min(sp)*n<=3|min(sds)==0)
{sp[sp==min(sp)]=0
sp[sp==max(sp)]=1
mus=rep(mean(x, na.rm=TRUE), K)
sds=rep(sd(x, na.rm=TRUE), K)
loglik=loglik.null
KS.p=1
d.cdf=NA
} else {if (loglik<loglik.null) {loglik=loglik.null}}

if (verbal) {print(paste("Converge at iteration ", B))}

fa=function(ix) sp[1]*dnorm(ix, mus[1], sds[1])
fb=function(ix) sp[2]*dnorm(ix, mus[2], sds[2])


chisq.p=NA
if (loglik!=loglik.null)
{#cross=sx[tpf][which(fitts[tpf]==min(fitts[tpf]))]
  if (include.normal&(!is.na(cross)))
  {gp=c(rep(0,length(x0)), rep(1,length(x)))
  chisq.p=chisq.test(table(data.frame(gp,c(x0<cross,x<cross))))$p.value
  }
}

if (plotTF)
{xx=c(x0,x)
sx=seq(min(xx), max(xx), length.out = 100)
fita=fa(sx)
fitb=fb(sx)
fit=fita+fitb

hx=hist(x, max(30,round(n/5)), plot=FALSE);
hx0=hist(x0, max(30,round(n/5)), plot=FALSE);

plot( hx, col=4, border= 4, xlim=c(min(xx), max(xx)), xlab="Normalized gene expression",
      main=tit)  # first histogram

plot( hx0, col=3, border=rgb(0, 1, 0, 1/4), add=TRUE)

points(sx, fita*n/sum(hx[[3]]), lwd=2, col=2, type="l")
points(sx, fitb*n/sum(hx[[3]]), lwd=2, col=2, type="l")
points(sx, fit *n/sum(hx[[3]]), lwd=5, col=2, type="l")
points(sx, fit *n/sum(hx[[3]]), lwd=2, col=7, type="l")
if (exists(as.character("normalmixEM")))
{mout=normalmixEM(x, k=2, fast = TRUE, arbmean = TRUE, epsilon = 1e-11)
mfita=mout$lambda[1]*dnorm(sx, mout$mu[1], mout$sigma[1])*1
mfitb=mout$lambda[2]*dnorm(sx, mout$mu[2], mout$sigma[2])*1
mfit=mfita+mfitb
points(sx, mfita*n/sum(hx[[3]]), lwd=2, col=2, type="l")
points(sx, mfitb*n/sum(hx[[3]]), lwd=2, col=2, type="l")
points(sx, mfit *n/sum(hx[[3]]), lwd=4, col=2, type="l")
}
points(sx, dnorm(sx, mean(x), sd(x)) *n/sum(hx[[3]]), lwd=1, col=8, type="l")
points(sx, dnorm(sx, mean(x), sd(x)) *n/sum(hx[[3]]), lwd=1, col=8, type="l")
abline(v=cross, col=7)
}
out=list("Proportion"=sp, "Means"=mus, "SDs"=sds, "loglik.null"=loglik.null, "loglik"=loglik, "sd.sd.ratio"=min(sds)/max(sds), "cutoff"=cross, "x"=x, "x0"=x0, "-2logLRT"=2*(loglik-loglik.null), "chisq.p"=chisq.p, "KS.p"=KS.p)

return(out)
}

