#' A function for performing box-cox transformation
#'
#' This function performs box-cox transformation.
#' @param x data values for the group that box-cox transformation is based on.
#' @param x0 data values for the group using the tranformation parameter from the other group.
#' @keywords box-cox
#' @export
#' @examples
#' FUN.boxcox()
FUN.boxcox=function(x, x0)
{box= boxcox(exp(x)~1, lambda=seq(-8, 8, .1), plotit =FALSE)
cox=data.frame(box$x, box$y)
cox2=cox[with(cox, order(-cox$box.y)),]
blambda=cox2[1, "box.x"]
if (blambda>0)
{x=(exp(x)^blambda-1)/blambda
x0=(exp(x0)^blambda-1)/blambda
} else
  if (blambda<0)
  {x=-1 * exp(x) ^ blambda
  x0=-1 * exp(x0) ^ blambda
  }
return(list(x, x0))
}
