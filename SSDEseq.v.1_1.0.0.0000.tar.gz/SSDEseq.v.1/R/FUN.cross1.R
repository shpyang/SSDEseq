#' A function for idenfity the location where two CDF cross (without performing KS test)
#'
#' This function idenfities the location where two CDF cross, (without performing KS test).
#' @param xx data values
#' @param n number of observations
#' @param mus means of the data where the two CDF are associated with.
#' @param sds standard deviations of the data where the two CDF are associated with.
#' @param sp the two proportions of the data where the two CDF are associated with.
#' @keywords cross
#' @export
#' @examples
#' FUN.cross1()
FUN.cross1=function(xx, n, mus, sds, sp)
{n.out=1000
sx=seq(min(xx), max(xx), length.out = n.out)
fa=function(ix) sp[1]*dnorm(ix, mus[1], sds[1])
fb=function(ix) sp[2]*dnorm(ix, mus[2], sds[2])
fita=fa(sx)
fitb=fb(sx)

fitts=abs(fita-fitb)
tpf=turnpoints(fitts)$tppos
cross=sx[tpf][which(fitts[tpf]==min(fitts[tpf]))]

if (length(tpf)>5)
{simx1=rnorm(10000, mus[1], sds[1])
simx2=rnorm(10000, mus[2], sds[2])
simx=sort(c(simx1, simx2))
c1=ecdf(simx1)
c2=ecdf(simx2)
d.cdf=abs(c1(simx)-c2(simx))
md.cdf=max(d.cdf)
KScross=simx[which(d.cdf==md.cdf)][1]
diff.2cross=abs(sx[tpf]-KScross)
cross=sx[tpf][which(diff.2cross==min(diff.2cross))]
cross=NA
}

return(list(cross=cross))
}
