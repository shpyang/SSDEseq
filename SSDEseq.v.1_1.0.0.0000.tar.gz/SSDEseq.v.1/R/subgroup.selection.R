#' A function for identifying conponent distributions
#'
#' This function identifis TWO conponent distributions.
#' @param Mx data matrix.
#' @param outp output data from SSDEseq.
#' @param boot.LRT threshold loglikelihood ratio test statistic.
#' @param n.group number of group to be created.
#' @param plotTF whether create a plot.
#' @keywords creat subgroups
#' @export
#' @examples
#' subgroup.selection()
subgroup.selection=function(Mx, outp, boot.LRT, n.group, plotTF)
{if (missing(plotTF)) {plotTF=FALSE}
  sig=outp[outp$chisq.p<0.05/nrow(outp),]
  sig=sig[(!is.na(sig$`X.2logLRT`))&(!is.na(sig$`X.2logLRT`))&(sig$`X.2logLRT`>boot.LRT),]
  sig=sig[sig$minor.proportion >.03,]
  sig=sig[sig$t.p< (0.05/nrow(outp)),]
  sig=sig[!is.na(sig$cutoff),]
  sig=sig[sig$KS.p<0.05/nrow(outp),]
  ogroup=FUN.LRT(-log10(sig$KS.p),-log10(sig$KS.p), boxcox=FALSE, include.normal = FALSE, useKS=TRUE)
  if (ogroup$`-2logLRT`>30)
  {sig=sig[-log10(sig$KS.p)>ogroup$cutoff,]}


  Msig=Mx[row.names(Mx)%in%sig$gene, ]

  Mcor=(cor((Msig)))
  c.dist=dist(Mcor)
  c.fit=hclust(c.dist)
  c.groups <- cutree(c.fit, k=n.group)

  if (plotTF) {plot(c.fit)
    rect.hclust(c.fit, k=n.group, border=6, which=3)
    heatmap.2(Mcor, hclustfun = hclust, col=redgreen(75), trace="none")
    heatmap.2(cor(t(Msig)), hclustfun = hclust, col=redgreen(75), trace="none")
  }

  dist = dist(t(Msig))
  fit = hclust(dist)
  groups <- cutree(fit, k=n.group)

  if (plotTF) {fit$labels=substr(fit$labels, 12, 17)
  plot(fit)
  rect.hclust(fit, k=n.group, border=c(4,2), which=c(5,6))
  heatmap.2(as.matrix((Msig)), hclustfun = hclust, col=redgreen(75), trace="none")
  }


  gid=data.frame(ID=names(groups), group=groups)

  return(gid)
}



